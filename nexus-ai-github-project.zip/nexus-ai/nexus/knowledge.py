"""Small local TF-IDF retrieval layer; no vector database or GPU required."""
from __future__ import annotations
import json
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class KnowledgeBase:
    def __init__(self, path: str = "data/knowledge_base.json"):
        self.path = Path(path)
        self.documents = json.loads(self.path.read_text(encoding="utf-8"))
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self.matrix = self.vectorizer.fit_transform(
            [f"{d['title']} {d['content']}" for d in self.documents]
        )

    def search(self, query: str, top_k: int = 3) -> list[dict]:
        query_vector = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vector, self.matrix).ravel()
        ranked = scores.argsort()[::-1][:top_k]
        results = []
        for idx in ranked:
            if scores[idx] > 0:
                item = dict(self.documents[idx])
                item["relevance"] = round(float(scores[idx]), 3)
                results.append(item)
        return results
