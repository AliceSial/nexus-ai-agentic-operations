"""LangGraph orchestration for request triage and response drafting."""
from __future__ import annotations
import os
from typing import TypedDict
from langgraph.graph import StateGraph, END
from nexus.intelligence import classify_request, score_lead
from nexus.knowledge import KnowledgeBase

class WorkflowState(TypedDict, total=False):
    message: str
    budget: float
    urgency: str
    category: str
    score: int
    priority: str
    reasons: list[str]
    context: list[dict]
    draft: str
    provider: str

def _classify(state: WorkflowState) -> WorkflowState:
    return {"category": classify_request(state["message"])}

def _score(state: WorkflowState) -> WorkflowState:
    result = score_lead(state["message"], state.get("budget", 0), state.get("urgency", "Normal"))
    return {"score": result["score"], "priority": result["priority"], "reasons": result["reasons"]}

def _retrieve(state: WorkflowState) -> WorkflowState:
    kb = KnowledgeBase()
    return {"context": kb.search(state["message"], top_k=3)}

def _draft(state: WorkflowState) -> WorkflowState:
    context = state.get("context", [])
    context_text = "\n".join(f"- {d['title']}: {d['content']}" for d in context)
    api_key = os.getenv("GROQ_API_KEY", "").strip()
    if api_key:
        try:
            from langchain_groq import ChatGroq
            from langchain_core.messages import HumanMessage, SystemMessage
            model = ChatGroq(
                model=os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"),
                temperature=0.2,
                api_key=api_key
            )
            response = model.invoke([
                SystemMessage(content=(
                    "You are NEXUS, a careful business operations copilot. "
                    "Draft a concise, professional response. Use only the supplied context "
                    "for service claims. If details are missing, ask a clarifying question. "
                    "Never claim an action was completed. This is a draft for human review."
                )),
                HumanMessage(content=(
                    f"Request category: {state.get('category')}\n"
                    f"Customer message: {state['message']}\n"
                    f"Retrieved knowledge:\n{context_text or 'No matching knowledge found.'}\n"
                    "Write a helpful reply draft and one suggested next step."
                ))
            ])
            return {"draft": response.content, "provider": "Groq LLM"}
        except Exception as exc:
            fallback_note = f"LLM unavailable ({type(exc).__name__}); using demo mode. "
    else:
        fallback_note = "Demo mode: add GROQ_API_KEY to enable LLM drafting. "
    category = state.get("category", "general")
    if category == "sales":
        draft = "Thank you for sharing your project requirements. We can explore a suitable solution. "
        draft += "Could you share your preferred integrations, expected users, and target launch date?"
    elif category == "support":
        draft = "Thanks for reporting this issue. We can help investigate. "
        draft += "Please share the steps to reproduce it and any error message you are seeing."
    elif category == "billing":
        draft = "Thanks for contacting us about billing. "
        draft += "Please share the invoice or transaction reference through a secure support channel."
    else:
        draft = "Thanks for reaching out. Could you share a little more detail about the outcome you are hoping to achieve?"
    if context:
        draft += "\n\nRelevant internal guidance: " + context[0]["title"] + "."
    return {"draft": fallback_note + draft, "provider": "Rule-based demo"}

def build_workflow():
    graph = StateGraph(WorkflowState)
    graph.add_node("classify", _classify)
    graph.add_node("score", _score)
    graph.add_node("retrieve", _retrieve)
    graph.add_node("draft", _draft)
    graph.set_entry_point("classify")
    graph.add_edge("classify", "score")
    graph.add_edge("score", "retrieve")
    graph.add_edge("retrieve", "draft")
    graph.add_edge("draft", END)
    return graph.compile()

workflow = build_workflow()

def analyze_request(message: str, budget: float = 0, urgency: str = "Normal") -> dict:
    return workflow.invoke({"message": message, "budget": budget, "urgency": urgency})
