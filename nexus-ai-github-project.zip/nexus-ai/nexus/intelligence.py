"""Rule-based business intelligence used by the NEXUS workflow."""
from __future__ import annotations

def classify_request(message: str) -> str:
    text = message.lower()
    if any(k in text for k in ("invoice", "payment", "refund", "billing", "subscription")):
        return "billing"
    if any(k in text for k in ("bug", "error", "not working", "issue", "support", "problem")):
        return "support"
    if any(k in text for k in ("price", "quote", "budget", "hire", "project", "proposal", "service")):
        return "sales"
    return "general"

def score_lead(message: str, budget: float = 0.0, urgency: str = "Normal") -> dict:
    """Transparent heuristic score; not a prediction about a person's worth."""
    text = message.lower()
    score = 20
    reasons = []
    if budget >= 3000:
        score += 30
        reasons.append("Budget is at least $3,000")
    elif budget >= 1000:
        score += 20
        reasons.append("Budget is at least $1,000")
    elif budget > 0:
        score += 10
        reasons.append("A budget was provided")
    else:
        reasons.append("Budget not specified")

    if urgency.lower() == "urgent":
        score += 20
        reasons.append("Urgent timeline selected")
    elif urgency.lower() == "soon":
        score += 10
        reasons.append("Near-term timeline selected")

    intent_terms = ("need", "looking for", "want to build", "hire", "develop", "implement")
    if any(term in text for term in intent_terms):
        score += 15
        reasons.append("Message expresses purchase or implementation intent")

    if len(message.split()) >= 20:
        score += 10
        reasons.append("Detailed project context provided")

    score = min(score, 100)
    priority = "High" if score >= 70 else "Medium" if score >= 45 else "Low"
    return {"score": score, "priority": priority, "reasons": reasons}
