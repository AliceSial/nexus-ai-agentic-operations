"""Local SQLite persistence for demo interactions."""
from __future__ import annotations
import sqlite3
from pathlib import Path
import pandas as pd

DB_PATH = Path(".nexus/interactions.db")

def _connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)

def save_interaction(result: dict) -> None:
    with _connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS interactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                category TEXT, priority TEXT, score INTEGER,
                message TEXT, draft TEXT
            )
        """)
        con.execute(
            "INSERT INTO interactions(category, priority, score, message, draft) VALUES(?,?,?,?,?)",
            (result["category"], result["priority"], result["score"],
             result["message"], result["draft"])
        )

def load_interactions() -> pd.DataFrame:
    with _connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS interactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                category TEXT, priority TEXT, score INTEGER,
                message TEXT, draft TEXT
            )
        """)
        return pd.read_sql_query("SELECT * FROM interactions ORDER BY id DESC", con)
