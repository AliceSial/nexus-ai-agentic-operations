from nexus.intelligence import classify_request, score_lead

def test_classifies_sales_request():
    assert classify_request("We need a quote for an AI assistant") == "sales"

def test_classifies_billing_request():
    assert classify_request("I have a question about my invoice payment") == "billing"

def test_high_budget_urgent_lead_scores_high():
    result = score_lead(
        "We need to implement an AI platform for our business and want to hire a developer.",
        budget=5000,
        urgency="Urgent"
    )
    assert result["priority"] == "High"
    assert result["score"] >= 70
